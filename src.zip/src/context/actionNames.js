export const setFilterBy = "setFilterBy";
export const setSortBy = "setSortBy";
export const setItemsOnPage = "setItemsOnPage";
export const setSelectedPair = "setSelectedPair";
export const setSelectedToken = "setSelectedToken";
export const setTimeFrame = "setTimeFrame";
