export const timestampToDate = (date) => {
  var newDate = new Date(date);
  return newDate;
};
