import React from "react";
import * as Styled from "./styles";

export const Container = ({ children }) => {
  return <Styled.Container> {children}</Styled.Container>;
};
