import { deviceQueries } from "config/viewSizes";
import styled from "styled-components";

export const TokenPairs = styled.div`
  display: flex;
  flex-direction: column;
  gap: 10px;
`;
