import styled from "styled-components";

export const Loader = styled.div`
  padding: 1rem 0;
`;
