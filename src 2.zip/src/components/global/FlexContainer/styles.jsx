import styled from "styled-components";

export const StyledFlexContainer = styled.div`
  display: flex;
`;
