export const dateRangeOptions = [
  {
    value: 50,
    name: 50,
  },
  {
    value: 100,
    name: 100,
  },
  {
    value: 150,
    name: 150,
  },
];
