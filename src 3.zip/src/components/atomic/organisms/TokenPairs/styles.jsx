import { deviceQueries } from "config/viewSizes";
import styled from "styled-components";

export const TokenPairs = styled.div`
  display: grid;
  gap: 10px;
`;
