import React from "react";
import { StyledFlexContainer } from "./styles";

export const FlexContainer = ({ children }) => {
  return <StyledFlexContainer>{children}</StyledFlexContainer>;
};
